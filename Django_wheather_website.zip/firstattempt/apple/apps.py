from django.apps import AppConfig


class AppleConfig(AppConfig):
    name = 'apple'
