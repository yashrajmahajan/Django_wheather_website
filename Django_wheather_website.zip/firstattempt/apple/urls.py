from django.urls import path
from django.contrib.staticfiles.urls import staticfiles_urlpatterns

from . import views
# from below => 1.path method. 2. when call that <name> e.g. add.  3. name of method where that declear e.g. view.home   4.  name in ' '.
urlpatterns = [
    path('', views.home, name = 'home'),
    path('add', views.add, name = 'add'),
    path('nums', views.nums, name = 'nums'),
    
    ]

urlpatterns += staticfiles_urlpatterns()