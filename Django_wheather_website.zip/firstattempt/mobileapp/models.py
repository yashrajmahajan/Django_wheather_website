from django.db import models

# Create your models here.
class Dyna:

    id: int
    name: str
    image: str
    price: int
    month: str
    offer: bool