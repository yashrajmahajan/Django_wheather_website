

# cnx1 = pymysql.connect (user=usr, max_allowed_packet=1073741824, password=pas, host=aws_host,database=db)
# cursor1 = cnx1.cursor ()
# print ("done")
# update_name = "insert into tbl_product(product_name, price,c_id) values (%s,%s,%s)"
# val = ('Amul milk', '60','1')
# cursor1.execute (update_name, val)
# cnx1.commit ()
# cnx1.close ()
def inser_uid(key):
    #First run the blochchain file
    #then
    import urllib.request
    # open a connection to a URL using urllib
    urllib.request.urlopen('http://127.0.0.1:5000/mine_block')



def update_qr_count(uid_id):
    import pymysql

    aws_host = 'localhost'
    usr = "root"
    pas = ""
    dbb = "product_detection"
    add_data = "select view_count from tbl_assign where uid_id = '" +uid_id+ "' "
    cnx = pymysql.connect(user=usr, max_allowed_packet= 1073741824, password=pas, host=aws_host, database=dbb)
    cursor = cnx.cursor ()
    cursor.execute (add_data)
    records = cursor.fetchone ()
    cnx.commit ()
    cnx.close ()
    records = int(list(records)[0])

    cnx = pymysql.connect (user=usr, max_allowed_packet=1073741824, password=pas, host=aws_host,database=dbb)
    cursor = cnx.cursor ()
    print ("done")
    update_name = "UPDATE tbl_assign set view_count = (%s) where uid_id = '" +uid_id+ "' "
    val = (records+1)
    cursor.execute (update_name, val)
    cnx.commit ()
    cnx.close ()

def assign_product_key():
    import pymysql
    import pyqrcode
    import png
    from pyqrcode import QRCode
    import qrcode

    aws_host = 'localhost'
    usr = "root"
    pas = ""
    dbb = "product_detection"

    add_data = "select id from tbl_product"
    cnx = pymysql.connect(user=usr, max_allowed_packet= 1073741824, password=pas, host=aws_host, database=dbb)
    cursor = cnx.cursor ()
    cursor.execute (add_data)
    records = cursor.fetchall ()
    cnx.commit ()
    cnx.close ()

    add_data1 = "select id from tbl_uid where status = 0"
    cnx = pymysql.connect(user=usr, max_allowed_packet= 1073741824, password=pas, host=aws_host, database=dbb)
    cursor = cnx.cursor ()
    cursor.execute (add_data1)
    records2 = cursor.fetchall ()
    cnx.commit ()
    cnx.close ()
    
    for i in range(0,len(records)):
        p_id = records[i][0]
        uid_id = records2[i][0]
        #when scanned product first time
        cnx1 = pymysql.connect (user=usr, max_allowed_packet=1073741824, password=pas, host=aws_host,database=dbb)
        cursor1 = cnx1.cursor ()
        update_name = "insert into tbl_assign(product_id,uid_id,view_count) values (%s,%s,%s)"
        val = (p_id,uid_id,0)
        cursor1.execute (update_name, val)
        cnx1.commit ()
        cnx1.close ()

        cnx = pymysql.connect (user=usr, max_allowed_packet=1073741824, password=pas, host=aws_host,database=dbb)
        cursor = cnx.cursor ()
        print ("done")
        update_name = "UPDATE tbl_uid set status = (%s),product_id = (%s) where id = '" +str(uid_id)+ "' "
        val = ('1',p_id)
        cursor.execute (update_name, val)
        cnx.commit ()
        cnx.close ()
        #now make a qr for all products
        pp_id = str(p_id)
        uu_id = str(uid_id)
        add_data = "select product_name, price from tbl_product where id = "+pp_id+""
        cnx = pymysql.connect(user=usr, max_allowed_packet= 1073741824, password=pas, host=aws_host, database=dbb)
        cursor = cnx.cursor ()
        cursor.execute (add_data)
        p_details = cursor.fetchone ()
        cnx.commit ()
        cnx.close ()
        product = str(list(p_details)[0])
        price = str(list(p_details)[1])

        add_data = "select uid_code from tbl_uid where id = "+uu_id+""
        cnx = pymysql.connect(user=usr, max_allowed_packet= 1073741824, password=pas, host=aws_host, database=dbb)
        cursor = cnx.cursor ()
        cursor.execute (add_data)
        u_details = cursor.fetchone ()
        cnx.commit ()
        cnx.close ()
        u_key = str(list(u_details)[0])

        #data = 'http://127.0.0.1:8000/'
        data = 'Product: '+product+', Price: '+price+', Product Key: xxxxxxxxxx'+u_key[-4:]+'. Click on link to verify product: http://127.0.0.1:8000/' 
        img = qrcode.make(data)
        img.save('mobileapp/qr_codes/{}.png'.format(product))



def most_scanned():
    import pymysql

    aws_host = 'localhost'
    usr = "root"
    pas = ""
    dbb = "product_detection"

    add_data = "select view_count from tbl_assign order by view_count desc"
    cnx = pymysql.connect(user=usr, max_allowed_packet= 1073741824, password=pas, host=aws_host, database=dbb)
    cursor = cnx.cursor ()
    cursor.execute (add_data)
    records = cursor.fetchone ()
    cnx.commit ()
    cnx.close ()
    if records != None:
        records = str(list(records)[0])
    else:
        records = '0'

    return records

def top3_scanned():
    import pymysql

    aws_host = 'localhost'
    usr = "root"
    pas = ""
    dbb = "product_detection"

    add_data = "select view_count from tbl_assign order by view_count desc limit 3"
    cnx = pymysql.connect(user=usr, max_allowed_packet= 1073741824, password=pas, host=aws_host, database=dbb)
    cursor = cnx.cursor ()
    cursor.execute (add_data)
    records = cursor.fetchall ()
    cnx.commit ()
    cnx.close ()
    pro1 = str(records[0][0])
    pro2 = str(records[1][0])
    pro3 = str(records[2][0])

    return pro1,pro2,pro3

def total_products():
    import pymysql

    aws_host = 'localhost'
    usr = "root"
    pas = ""
    dbb = "product_detection"

    add_data = "select count(id) from tbl_product"
    cnx = pymysql.connect(user=usr, max_allowed_packet= 1073741824, password=pas, host=aws_host, database=dbb)
    cursor = cnx.cursor ()
    cursor.execute (add_data)
    records = cursor.fetchall ()
    cnx.commit ()
    cnx.close ()
    if records != None:
        records = str(list(records)[0])
    else:
        records = '0'
    return records

def generate_qr():
    import qrcode
    import pymysql

    aws_host = 'localhost'
    usr = "root"
    pas = ""
    dbb = "product_detection"

    add_data = "select id from tbl_product"
    cnx = pymysql.connect(user=usr, max_allowed_packet= 1073741824, password=pas, host=aws_host, database=dbb)
    cursor = cnx.cursor ()
    cursor.execute (add_data)
    records = cursor.fetchall ()
    cnx.commit ()
    cnx.close ()

    data = 'http://127.0.0.1:8000/{}'
    img = qrcode.make(data)
    img.save('img.png')