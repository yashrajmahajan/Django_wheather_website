from django.shortcuts import render
from django.http import HttpResponse
from numpy import record
from .models import Dyna
import pymysql
import requests
import json


#write db credentials
aws_host = 'localhost'
usr = "root"
pas = ""
db = "django_task"

#======================================
# Create your views here.
def call_wheather_api(alti,lati):
    url = 'https://api.weather.gov/points/{},{}'

    payload={}
    headers = {}
    try:
        print('hi')
        response = requests.request("GET", url.format(alti,lati), headers=headers, data=payload, verify=False)
        response = response.text
        print(response)
        resp = json.loads (response)

    except Exception as e :
        print(e)
        resp = 'error'
   
    return resp

def find_temp(x,y):
    url = 'https://api.weather.gov/gridpoints/TOP/{},{}/forecast'

    payload={}
    headers = {}

    try:
        print('hi')
        response = requests.request("GET", url.format(x,y), headers=headers, data=payload, verify=False)
        response = response.text
        print(response)
        resp = json.loads (response)

    except Exception as e :
        print(e)
        
   
    return resp








# def index(request):

#     p1 = Dyna() 
#     p = [p1]
#     data2 = render(request, "index.html", {'p': p})
#     return data2

def index(request):                              #create home method for webpage view
    return render(request, "index.html", {'nam' : 'yash'})

def add(request):

    alti = str(request.GET['n1'])
    lati = str(request.GET['n2'])

    add_data = "insert into tbl_location(alti,lati) values (%s,%s)"
    val = (alti,lati)
    cnx = pymysql.connect (user=usr, max_allowed_packet=1073741824, password=pas, host=aws_host,database=db)
    cursor = cnx.cursor ()
    cursor.execute (add_data, val)
    cnx.commit ()
    cnx.close ()

    anss = "Your Co-ordinates is added into the database"

    # data = call_wheather_api('39.7456','-97.0892')
    data = call_wheather_api(alti,lati)
    # alti = 39.7456
    # lati = -97.0892
    # if data["status"] != 404:
    try:
        x = data["properties"]["gridX"]
        print('x',x)
        y = data["properties"]["gridY"]
        print('y',y)
        city= data["properties"]["relativeLocation"]["properties"]["city"]
        state = data["properties"]["relativeLocation"]["properties"]["state"]

        resp = find_temp(x,y)
        #Today only
        name =  resp["properties"]["periods"][0]["name"]
        temp =  resp["properties"]["periods"][0]["temperature"]
        wspeed= resp["properties"]["periods"][0]["windSpeed"]
        forcat= resp["properties"]["periods"][0]["shortForecast"]
        # icon =  resp["properties"]["periods"][0]["icon"]
        valid = 'Valid Co-ordinates.'
        ans = {'valid':valid,'result': anss,'alti':alti,'lati':lati,'city': city,'state': state,'name':name,'temp':temp,'wspeed':wspeed,'forcat':forcat}

    except:
        x,y,city,state= 0,0,'NULL','NULL'
        city,state,name,temp,wspeed,forcat,icone= 'NA','NA',' ','NA','NA','NA','NA'
        valid = 'Invalid Co-ordinates, Please use US co-ordinates.'
        ans = {'valid':valid,'result': anss,'alti':alti,'lati':lati,'city': city,'state': state,'name':name,'temp':temp,'wspeed':wspeed,'forcat':forcat}

    
    return render(request, "index.html", ans)

