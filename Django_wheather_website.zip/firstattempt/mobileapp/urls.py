from django.urls import path
from django.contrib.staticfiles.urls import staticfiles_urlpatterns

from . import views
# from below => 1.page path. 2. when call that <name> e.g. add.  3. name of method where that declear e.g. view.home   4.  name in ' '.
urlpatterns = [
    path('', views.index, name = 'index'),
    path('add', views.add, name = 'add')
    ]

urlpatterns += staticfiles_urlpatterns()
