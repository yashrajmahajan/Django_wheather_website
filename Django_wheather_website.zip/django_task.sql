-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 06, 2022 at 03:48 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `django_task`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_location`
--

CREATE TABLE `tbl_location` (
  `id` int(11) NOT NULL,
  `alti` varchar(80) DEFAULT NULL,
  `lati` varchar(80) DEFAULT NULL,
  `city` varchar(80) DEFAULT NULL,
  `created_date` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_location`
--

INSERT INTO `tbl_location` (`id`, `alti`, `lati`, `city`, `created_date`) VALUES
(2, '2', '3', NULL, '2022-04-06 16:05:25'),
(3, '2', '3', NULL, '2022-04-06 16:06:41'),
(4, '2', '3', NULL, '2022-04-06 16:08:45'),
(5, '39.7456', '-97.0892', NULL, '2022-04-06 16:10:56'),
(6, '39.7456', '-97.0892', NULL, '2022-04-06 16:13:28'),
(7, '39.7456', '-97.0892', NULL, '2022-04-06 16:28:19'),
(8, '18.516726', '73.856255', NULL, '2022-04-06 16:29:26'),
(9, '18.516726', '73.856255', NULL, '2022-04-06 16:33:34'),
(10, '18.516726', '73.856255', NULL, '2022-04-06 16:37:00'),
(11, '18.516726', '73.856255', NULL, '2022-04-06 16:39:22'),
(12, '18.516726', '73.856255', NULL, '2022-04-06 16:41:16'),
(13, '18.516726', '73.856255', NULL, '2022-04-06 16:47:11'),
(14, '18.516726', '73.856255', NULL, '2022-04-06 16:47:38'),
(15, '18.516726', '73.856255', NULL, '2022-04-06 16:50:44'),
(16, '18.516726', '73.856255', NULL, '2022-04-06 17:01:27'),
(17, '18.516726', '73.856255', NULL, '2022-04-06 17:07:26'),
(18, '28.644800', '77.216721', NULL, '2022-04-06 17:08:41'),
(19, '28.644800', '77.216721', NULL, '2022-04-06 17:10:36'),
(20, '28.644800', '77.216721', NULL, '2022-04-06 17:23:36'),
(21, '28.644800', '77.216721', NULL, '2022-04-06 17:33:16'),
(22, '28.644800', '77.216721', NULL, '2022-04-06 17:36:21'),
(23, '18.516726', '73.856255', NULL, '2022-04-06 17:46:08'),
(24, '28.644800', '77.216721', NULL, '2022-04-06 17:46:25'),
(25, '28.644800', '77.216721', NULL, '2022-04-06 18:46:07'),
(26, '28.644800', '77.216721', NULL, '2022-04-06 18:47:32'),
(27, '28.644800', '77.216721', NULL, '2022-04-06 18:48:33'),
(28, '28.644800', '77.216721', NULL, '2022-04-06 18:49:53'),
(29, '40.730610', '-73.935242', NULL, '2022-04-06 18:53:17'),
(30, '40.730610', '-73.935242', NULL, '2022-04-06 18:56:18'),
(31, '40.730610', '-73.935242', NULL, '2022-04-06 18:58:34'),
(32, '40.730610', '-73.935242', NULL, '2022-04-06 18:59:41');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_location`
--
ALTER TABLE `tbl_location`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_location`
--
ALTER TABLE `tbl_location`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
